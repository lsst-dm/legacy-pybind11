version_info = (1, 7)
__version__ = '.'.join(map(str, version_info))
