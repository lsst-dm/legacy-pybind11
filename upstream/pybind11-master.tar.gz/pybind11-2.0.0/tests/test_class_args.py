

def test_class_args():
    # There's basically nothing to test here; just make sure the code compiled and declared its definition
    from pybind11_tests import class_args_noop
    class_args_noop()
